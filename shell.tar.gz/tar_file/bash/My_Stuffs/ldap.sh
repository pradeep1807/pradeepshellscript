#!/bin/sh
### IP Server LDAP 192.168.1.100
ldapsearch -x -h 164.100.14.58 -b ” -p 636 -s base > /dev/null
# echo $?
if [ $? = “0” ]; then echo “$(date) – Connection OK” >> /tmp/ldap_con.log
else echo “$(date) – Connection NOT OK” >> /tmp/ldap_con.log
fi
