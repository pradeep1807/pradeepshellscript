#!/bin/bash
echo `date` >> /root/monitoring/java_process.txt
echo `netstat -tunlpa | grep java | grep -i est | wc -l` >> /root/monitoring/java_process.txt
