#!/bin/bash
r=$(cat /proc/loadavg | awk -F. '{print $1}')
if [ $r -ge 2 ]
then
echo "Warning: High Server Load on: `date` `hostname -i` Load Average: $r" >> /root/monitoring/load.txt
fi
