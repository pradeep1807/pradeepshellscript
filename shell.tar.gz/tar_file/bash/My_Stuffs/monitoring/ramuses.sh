#!/bin/bash
#eCheck RAM and SWAP Usages
free -h | grep -v + > /tmp/ramcache
echo -e '\E[32m'"Ram Usages :`date`" >> /root/monitoring/ram.txt
cat /tmp/ramcache | grep -v "Swap" >> /root/monitoring/ram.txt 
echo -e '\E[32m'"Swap Usages :`date`" >> /root/monitoring/ram.txt
cat /tmp/ramcache | grep -v "Mem" >> /root/monitoring/ram.txt

