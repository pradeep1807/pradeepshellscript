#!/bin/bash

 echo -e "\e[1;31m ########################--WELCOME SERVER ADMIN--###################################### \e[0m  "

 echo -e "\e[1;31m Hostname                : `hostname`                                                   \e[0m  "
 echo -e "\e[1;31m Host IP                 : `hostname -I`                                                \e[0m  "
 echo -e "\e[1;31m SAN name                : `df -h | awk 'BEGIN{IGNORECASE = 1} /Filesystem/'`           \e[0m  "
 echo -e "\e[1;31m SAN utilization(eOffice): `df -h | grep eOffice`                                       \e[0m  "
 echo -e "\e[1;31m SAN utilization(Uploads): `df -h | grep Uploads`                                       \e[0m  "
 echo -e "\e[1;31m SAN utilization(Pims)   : `df -h | grep PIMS`                                          \e[0m  "

 echo -e "\e[1;31m #######################################################################################\e[0m  "

