<?php
$ds=ldap_connect("ldaps://164.100.14.58");
ldap_set_option($ds, LDAP_OPT_PROTOCOL_VERSION, 3);
$loginid="uid=darpg.auth,ou=People,o=inoc services,o=Application Services,o=nic.in,dc=nic,dc=in";
$passwd="Auth.darpg@123";
$r=ldap_bind($ds,$loginid,$passwd);
if(!$r) die("ldap_bind failed<br>");

$sr=ldap_search($ds,"o=nic.in,dc=nic,dc=in","cn=Sandeep Jand");

$info = ldap_get_entries($ds,$sr);

print_r($info);

?>

