#!/bin/bash
# set the subject
SUBJECT="THIS IS MY EMAIL SUBJECT"
# set the recipient email address
EMAIL="pradeep.nicindia@gmail.com"
#send the message
/bin/mail -s "$SUBJECT" "$EMAIL" <<MSG
this is my test message
MSG
