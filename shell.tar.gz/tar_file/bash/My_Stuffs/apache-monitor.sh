#!/bin/sh

    # Define some variables#
    TAIL="/usr/bin/tail -f"
    # TAIL command can also be -10, -15, -20, -30
    LOG="/var/log/httpd/access_log"
    TOTAL=`netstat -pant | grep :80 | wc -l`
    TOTAL2=`netstat -pant | grep :443 | wc -l`
    echo "There are $TOTAL port 80 connections."
    echo "There are $TOTAL2 port 443 connections."
    uptime | awk '{print $8,$9,$10,$11,$12,$13,$14,$15}'

    #Let's do it#
    $TAIL $LOG | awk '{print$3 " " $8 " " $4 " " $6 " " $8 " " $9 " " $7}'

    #DONE

