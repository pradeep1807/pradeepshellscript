#!/bin/bash
if curl -s --head https://sparrow.eoffice.gov.in | grep "200 OK" #> /dev/null
  then 
    echo "The HTTP server on IAS is up!" #> /dev/null
  else
    echo "The HTTP server on IAS is down!"
fi
