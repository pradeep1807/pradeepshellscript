#!/bin/bash
SUBJECT="restart"
EMAIL="youremailaddress@gmail.com"
MESSAGE="/path/to/message.txt"
response=$(curl --write-out %{http_code} --connect-timeout 5  --silent --output /dev/null http://YOUR_SITE.com/index.html)
if [ $response -eq 200 ]
then
echo "All Working well";
else
echo "Launching"
(kill $(ps aux | grep '[h]ttpd' | awk '{print $2}'))
(apachectl restart)
/bin/mail -s "$SUBJECT" "$EMAIL" < $MESSAGE
fi
# Auth - Pradeep Kumar
