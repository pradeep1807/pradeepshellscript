#!/bin/bash
response=$(curl --write-out %{http_code} --connect-timeout 5  --silent --output /dev/null http://YOUR_SITE.COM/index.html)
if [ $response -eq 200 ]
then
echo "All Working well";
else
echo "Restarting Service"
(apachectl restart)
fi
# Auth - Pradeep Kumar

<span style="font-family: Georgia, 'Times New Roman', 'Bitstream Charter', Times, serif; font-size: 13px; line-height: 19px;">
</span>
