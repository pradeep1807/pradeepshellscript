#!/bin/bash
NAME[0]="Pradeep"
NAME[1]="Kumar"
NAME[2]="Hello"
#echo "First Index: ${NAME[0]}"
#echo "Second Index: ${NAME[1]}"
#######print all line using one method both of them#######
#echo "First Method: ${NAME[*]}" 
echo "Second Method: ${NAME[@]}" 
