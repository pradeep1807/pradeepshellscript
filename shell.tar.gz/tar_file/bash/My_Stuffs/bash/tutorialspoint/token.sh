#!/bin/bash
for TOKEN in $*
do
echo $TOKEN
done
