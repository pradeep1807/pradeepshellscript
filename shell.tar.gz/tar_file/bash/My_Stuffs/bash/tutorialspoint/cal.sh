#!/bin/bash
echo -e "\e[1;32m Enter first value -> : $first \e[0m "
read first
echo -e "\e[0;31m Enter second value -> : $second \e[0m"
read second
add=`expr $first + $second` 
sub=`expr $first - $second` 
mul=`expr $first \* $second`
div=`expr $first / $second`
mod=`expr $first % $second`
assignment=`expr $first = $second`
equality=`expr $first == $second`
notequality=`expr $first != $second`
let "c=first*second"
squrt=$(echo "sqrt($c)" | bc)
squrt1=$(echo "sqrt($first)" | bc)
squrt2=$(echo "sqrt($second)" | bc)
#echo -e "  \e[1;32m Server IP  : $ip    \e[0m  "
echo -e  "  \e[1;32m Addition result -->  $add \e[0m"
echo -e  "  \e[0;33m Subtraction result -->  $sub \e[0m"
echo -e  "  \e[4;34m Multiplication result -->  $mul \e[0m"
echo -e  "  \e[1;96m Division result -->  $div \e[0m"
echo -e  "  \e[1;95m Modulus result -->  $mod \e[0m"
echo -e  "  \e[0;101m Assignment result -->  $assignment \e[0m"
echo -e  "  \e[0;10m Equality result --> $equality \e[0m"
echo -e  "  \e[1;35m Not equality --> $notequality \e[0m"
echo -e  "  \e[2;37m Square Root both value multiple --> $squrt \e[0m"
echo -e  "  \e[1;32m Square Root first value--> $squrt1 \e[0m"
echo -e  "  \e[0;31m Square Root second value--> $squrt2 \e[0m"
