#!/bin/bash
#case "$(curl -s --max-time 2 -I http://google.com | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
#  [23]) echo "HTTP connectivity is up";;
#  5) echo "The web proxy won't let us through";;
#  *) echo "The network is down or very slow";;
#esac
echo -e "\e[1;31m Welcome Pradeep ! To check Site Performance  \e[0m "
###########sparrow-ias########################
case "$(curl -s --max-time 2 -I http://sparrow.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
[23]) echo -e "\e[1;32m Sparrow-IAS HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m  Sparrow-IAS The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m  Sparrow-IAS The network is down or very slow \e[0m";;
esac
###########sparrow-ips########################
case "$(curl -s --max-time 2 -I http://sparrow-ips.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-IPS HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-IPS The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-IPS The network is down or very slow \e[0m";;
esac
###########sparrow-ifs########################
case "$(curl -s --max-time 2 -I http://sparrow-ifs.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-IFS HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-IFS The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-IFS The network is down or very slow \e[0m";;
esac
###########sparrow-css########################
case "$(curl -s --max-time 2 -I http://sparrow-css.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-CSS HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-CSS The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-CSS The network is down or very slow \e[0m";;
esac
###########sparrow-csss########################
case "$(curl -s --max-time 2 -I http://sparrow-csss.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-CSSS HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-CSSS The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-CSSS The network is down or very slow \e[0m";;
esac
###########sparrow-cga########################
case "$(curl -s --max-time 2 -I http://sparrow-cga.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-CGA HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-CGA The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-CGA The network is down or very slow \e[0m";;
esac
###########sparrow-epfo########################
case "$(curl -s --max-time 2 -I http://sparrow-epfo.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-EPFO HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-EPFO The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-EPFO The network is down or very slow \e[0m";;
esac
###########sparrow-icoas########################
case "$(curl -s --max-time 2 -I http://sparrow-icoas.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-ICOAS HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-ICOAS The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-ICOAS The network is down or very slow \e[0m";;
esac
###########sparrow-irs########################
case "$(curl -s --max-time 2 -I http://sparrow-irs.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-IRS HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-IRS The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-IRS The network is down or very slow \e[0m";;
esac
###########sparrow-moefccsci########################
case "$(curl -s --max-time 2 -I http://sparrow-moefccsci.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-MOEFCSSI HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-MOEFCSSI The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-MOEFCSSI The network is down or very slow \e[0m";;
esac
###########sparrow-dot########################
case "$(curl -s --max-time 2 -I http://sparrow-dot.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-DOT HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-DOT The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-DOT The network is down or very slow \e[0m";;
esac
###########sparrow-icls########################
case "$(curl -s --max-time 2 -I http://sparrow-icls.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-ICLS HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-ICLS The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-ICLS The network is down or very slow \e[0m";;
esac
###########sparrow-iis########################
case "$(curl -s --max-time 2 -I http://sparrow-iis.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-IIS HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-IIS The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-IIS The network is down or very slow \e[0m";;
esac
###########sparrow-SASMP########################
case "$(curl -s --max-time 2 -I http://sparrow-sasmp.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-SAS-MP HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-SAS-MP The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-SAS-MP The network is down or very slow \e[0m";;
esac
###########sparrow-chs-dental########################
case "$(curl -s --max-time 2 -I http://sparrow-chs-dental.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-CHS-DENTAL HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-CHS-DENTAL The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-CHS-DENTAL The network is down or very slow \e[0m";;
esac
###########sparrow-ces-morth########################
case "$(curl -s --max-time 2 -I http://sparrow-cesmorth.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-CES-MORTH HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-CES-MORTH The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-CES-MORTH The network is down or very slow \e[0m";;
esac
###########sparrow-cpes########################
case "$(curl -s --max-time 2 -I http://sparrow-cpes.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-CPES HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-CPES The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-CPES The network is down or very slow \e[0m";;
esac
###########sparrow-dgde########################
case "$(curl -s --max-time 2 -I http://sparrow-dgde.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-DGDE HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-DGDE The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-DGDE The network is down or very slow \e[0m";;
esac
###########sparrow-dgaqa########################
case "$(curl -s --max-time 2 -I http://sparrow-dgaqa.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-DGAQA HTTP connectivity is up \e[0m";;
  5) echo "Sparrow-DGAQA The web proxy won't let us through \e[0m";;
  *) echo "Sparrow-DGAQA The network is down or very slow \e[0m";;
esac
###########sparrow-dgqa########################
case "$(curl -s --max-time 2 -I http://sparrow-dgqa.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-DGQA HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-DGQA The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-DGQA The network is down or very slow \e[0m";;
esac
###########sparrow-IAAS/CAG########################
case "$(curl -s --max-time 2 -I http://sparrow.cag.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-CAG HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-CAG The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-CAG The network is down or very slow \e[0m";;
esac
###########sparrow-idas########################
case "$(curl -s --max-time 2 -I http://sparrow-dad.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-IDAS HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-IDAS The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-IDAS The network is down or very slow \e[0m";;
esac
###########sparrow-iofs########################
case "$(curl -s --max-time 2 -I http://sparrow-iofs.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-IOFS HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-IOFS The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-IOFS The network is down or very slow \e[0m";;
esac
###########sparrow-iss########################
case "$(curl -s --max-time 2 -I http://sparrow-iss.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-ISS HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-ISS The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-ISS The network is down or very slow \e[0m";;
esac
###########sparrow-its########################
case "$(curl -s --max-time 2 -I http://sparrow-its.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-ITS HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-ITS The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-ITS The network is down or very slow \e[0m";;
esac
###########sparrow-sss########################
case "$(curl -s --max-time 2 -I http://sparrow-sss.eoffice.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-SSS HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-SSS The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-SSS The network is down or very slow \e[0m";;
esac
###########sparrow-maharastra########################
case "$(curl -s --max-time 2 -I http://mahapar.maharashtra.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-MAHAPAR HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-MAHAPAR The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-MAHAPAR The network is down or very slow \e[0m";;
esac
###########sparrow-MOR########################
case "$(curl -s --max-time 2 -I http://sparrow.railnet.gov.in | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" in
  [23]) echo -e "\e[1;32m Sparrow-RAILNET HTTP connectivity is up \e[0m";;
  5) echo -e "\e[1;31m Sparrow-RAILNET The web proxy won't let us through \e[0m";;
  *) echo -e "\e[1;31m Sparrow-RAILNET The network is down or very slow \e[0m";;
esac














   
    
