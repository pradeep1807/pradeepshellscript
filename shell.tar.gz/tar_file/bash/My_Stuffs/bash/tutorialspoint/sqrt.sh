#!/bin/bash
#echo "Enter first value ->"
#read first
#echo "Enter second value ->"
#read second
#add=`expr $first + $second` 
#sub=`expr $first - $second` 
#mul=`expr $first \* $second`
#div=`expr $first / $second`
#mod=`expr $first % $second`
#assignment=`expr $first = $second`
#equality=`expr $first == $second`
#notequality=`expr $first != $second`
##echo -e "  \e[1;32m Server IP  : $ip    \e[0m  "
#echo -e  "  \e[1;32m Addition result -->  $add \e[0m"
#echo -e  "  \e[0;33m Subtraction result -->  $sub \e[0m"
#echo -e  "  \e[4;34m Multiplication result -->  $mul \e[0m"
#echo -e  "  \e[1;96m Division result -->  $div \e[0m"
#echo -e  "  \e[1;95m Modulus result -->  $mod \e[0m"
#echo -e  "  \e[0;101m Assignment result -->  $assignment \e[0m"
#echo -e  "  \e[0;10m Equality result --> $equality \e[0m"
#echo -e  "  \e[1;35m Not equality --> $notequality \e[0m"
a=3
b=9
let "c=b*a"
d=$(echo "sqrt ($c)" | bc)
echo $d
