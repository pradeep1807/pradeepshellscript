#!/bin/bash
#testing user variables
days=2
name="Avi"
echo "$name will go for $days days"
days=1
name="Deep"
echo "$name will go for $days days"
