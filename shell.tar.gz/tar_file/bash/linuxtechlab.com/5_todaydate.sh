#!/bin/bash
#copy the /home/test/logs directory listing to a log file
today=$(date +%y%m%d)
ls /bash/linuxtechlab.com/logs -al > log.$today
