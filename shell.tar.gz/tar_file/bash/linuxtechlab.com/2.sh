#!/bin/bash
#This will show us current user's info.
echo "Current user is:$USER"
echo "$USER has $UID UID"
echo "& his home path is $HOME"
echo "$USER user has home path is $HOME"
