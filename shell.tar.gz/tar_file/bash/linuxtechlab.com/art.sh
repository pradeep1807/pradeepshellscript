#!/bin/bash
#this script shows arithmetic operations
echo "Enter variable 1:-- "
read f
echo "Enter variable 2:-- "
read s
echo "Add of two number:-- $add"
echo "Sub of two number:-- $sub"
echo "Add of $add=[$f+$s]"
echo "Sub of $sub[$f-$s]"
