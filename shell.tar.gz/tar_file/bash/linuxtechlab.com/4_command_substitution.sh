#!/bin/bash
#https://linuxtechlab.com/3-bash-basic-script-variables/
#shows command substitution
var1=$(date)
echo "date & time are:" $var1
