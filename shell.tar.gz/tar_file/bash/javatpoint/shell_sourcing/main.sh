#!/bin/bash
source /bash/javatpoint/shell_sourcing/config.sh
echo "this is $user with $id."
