#!/bin/bash
user=JavaTpoint   #this is file name
id=2201                     # it is defined driven PID process id
