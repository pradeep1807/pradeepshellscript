#!/bin/sh
var1=Hello
var2=Linux
#
echo "$var1 $var2"
