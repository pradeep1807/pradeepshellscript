#!/bin/bash
echo "This scripts checks the existence of the messages file."
echo "Checking..."
if [ -f /var/log/messages ] 
then 
echo "/var/log.messages exists."
fi
echo 
echo "...done."
#These lines will print a message if the noclobber option is set:
#if [ -o noclobber ]
#then
#echo "Your files are protected against accidental overwriting using redirection."
#fi
