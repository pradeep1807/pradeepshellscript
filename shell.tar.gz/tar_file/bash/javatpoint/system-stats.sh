#!/bin/bash
CPUTIME=$(ps -eo pcpu | awk 'NR&gt;1' | awk '{tot=tot+$1} END {print tot}')
CPUCORES=$(cat /proc/cpuinfo | grep -c processor)
CPUTEMP=$(sensors | grep Core | awk -F: ' { print $2 } '| cut -c8-9 | tr &quot;n&quot; &quot; &quot; | awk '{tot=tot+$1} END {print tot}')
GPUTEMP=$(tail -n 1 /var/log/gputemp.log | cut -d &quot; &quot;  -f 2-16 | awk '{tot=tot+1+2+$3+$4+$5+$5+$6+$7+$8} END {print tot}' )
GPUCORES=8
echo &quot;
System Summary (collected `date`)
CPU Usage (average)       = `echo $CPUTIME / $CPUCORES | bc`%
CPU Temperature (average) = `echo $CPUTEMP / $CPUCORES | bc`c
GPU Temperature (average) = `echo $GPUTEMP / $GPUCORES | bc`c
Memory free (real)        = `free -m | head -n 2 | tail -n 1 | awk {'print $4'}` Mb
Memory free (cache)       = `free -m | head -n 3 | tail -n 1 | awk {'print $3'}` Mb
Swap in use               = `free -m | tail -n 1 | awk {'print $3'}` Mb
System Uptime             =`uptime`
Public IP                 = `dig +short myip.opendns.com @resolver1.opendns.com`
Disk Space Used           = `df / | awk '{ a = $4 } END { print a }'`
     
#&quot; &gt; /etc/motd


