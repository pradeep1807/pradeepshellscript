#!/bin/bash
if [ "$(whoami)" != 'root' ];then
echo "You have no permsission to run $0 as non-root user."
exit 1;
fi
