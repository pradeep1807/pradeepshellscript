#!/bin/bash
echo this script name is $0
echo The first argument is $1
read $1
echo The second argument is $2
read $2
echo The third argument is $3
read $3
echo  $$ PID of the script 
echo  $# Total number of arguments
echo  $? Represent last return code

