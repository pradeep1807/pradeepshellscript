#!/bin/bash
#
echo this script name is $0
#
echo The first arguments is $1
echo The second arguments is $2
echo And Third arguments is $3
#
echo \$ $$ PID of the script
echo \# $# Total number of arguments

