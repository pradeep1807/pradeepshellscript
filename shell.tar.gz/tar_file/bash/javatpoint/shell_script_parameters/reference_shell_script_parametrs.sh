#!/bin/bash
echo "$1-$9    represent positional parameters for argumetns one to nine"
echo "${10}-${n}   represent positional parameters for arguments after nine"
echo "$0            represent name of the script"
echo "$* represent all the arguments as a single string"
echo "$@  Same as $∗, but differ when enclosed in (")}
echo "$#  ( represent total number of argumetsn) " 
echo "$$ (PID of the script) "
echo "$? represent last return code"
echo "Read and Apply" 
