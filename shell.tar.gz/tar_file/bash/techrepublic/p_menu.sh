#!/bin/bash
quit=n 
while [  "$quit"   =   "n"  ] 
do 
clear 
echo 
echo "1. General system information" 
echo "2. Hardware utilisation information" 
echo "3. File management"
echo "4. User information"
echo "5. Information on network connectivity"
echo "6. Information on processes" 
echo "Q.Quit" 
echo 
echo "Enter choice" 
read choice 
case $choice in 
1)./gensysinfo
  read junk;;
2)./hardutilinfo
  read junk;;
3)./fileman 
  read junk;;
4)./userinfo
  read junk;;
5)./netinfo
  read junk;;
6)./procinfo 
  read junk;;
Q|q) quit=y;; 
*) echo "Try Again" 
sleep 1 
esac 
done 
echo "Thankyou, Come again"
