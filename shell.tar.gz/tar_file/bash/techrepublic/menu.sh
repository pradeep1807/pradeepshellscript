#!/bin/bash
clear
whiptail --msgbox "Entering networking sub-menu" 20 78
whiptail --title Networking --menu "Make your choice" 16 78 5 \
"1)" "Display info"
while read CHOICE
do
case $CHOICE in
1) ./displayinfo.sh
esac
done
