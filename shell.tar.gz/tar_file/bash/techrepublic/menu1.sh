#!/bin/bash
clear
whiptail --msgbox "Entering networking sub-menu" 20 78
trap 'rm -f choice$$' EXIT
while whiptail --title Networking --menu "Make your choice" 16 78 5 \
"1)" "Display info" "2)" "Another option" "3)" "something else" 2> choice$$
do read CHOICE < choice$$
case $CHOICE in
("1)") ./displayinfo.sh;;
(*) whiptail --msgbox "To Be Implemented." 20 78;;
esac
done
