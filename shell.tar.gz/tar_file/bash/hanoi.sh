#! /bin/bash
#
# The Towers Of Hanoi
# Bash script
# Copyright (C) 2000 Amit Singh. All Rights Reserved.
# http://hanoi.kernelthread.com
#
# Last tested under bash version 2.05b.0(13)-release
#

dohanoi() {
    case $1 in
    0)
        ;;
    *)
        dohanoi "$(($1-1))" $2 $4 $3
        echo move $2 "-->" $3
        dohanoi "$(($1-1))" $4 $3 $2
        ;;
    esac
}

case $# in
1)
    case $(($1>0)) in
    1)
        dohanoi $1 1 3 2
        exit 0;
        ;;
    *)
        echo "$0: illegal value for number of disks";
        exit 2;
        ;;
    esac
    ;;
*)
    echo "usage: $0 N"
    exit 1;
    ;;
esac
