#!/bin/bash
if [ "$1" == fish ]; then
echo "Hmmmmm fish... Tux happy!"
else
echo "Tux don't like that. Tux wants fish!"
fi

