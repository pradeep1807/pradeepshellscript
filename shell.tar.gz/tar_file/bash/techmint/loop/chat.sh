#!/bin/bash
echo "Hi Good Morning!"
echo "What is your name?"
read name
echo "$name,what are you doing?"
read well

