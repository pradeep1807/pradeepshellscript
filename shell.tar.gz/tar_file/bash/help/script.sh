#!/bin/bash

pass=abc

for i in $(seq 112 120);
do
ip=`echo "10.248.145.$i"`
host=$(sshpass -p $pass ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=quiet sparrow@$ip -T "hostname")
rhel=$(sshpass -p $pass ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=quiet sparrow@$ip -T "cat /etc/redhat-release")
cpu= $(sshpass -p $pass ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=quiet sparrow@$ip -T "nproc")
mem= $(sshpass -p $pass ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=quiet sparrow@$ip -T free -g |grep "Mem:" |awk -F' ' '{print $2 + 1}')
ts=  $(sshpass -p $pass ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=quiet sparrow@$ip -T df -h /eOffice/ | grep eOffice | awk -F' ' '{print $2}')
us=  $(sshpass -p $pass ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=quiet sparrow@$ip -T df -h /eOffice/ | grep eOffice | awk -F' ' '{print $3}')
da=  $(sshpass -p $pass ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=quiet sparrow@$ip -T df -h /eOffice/ | grep eOffice | awk -F' ' '{print $4}')
pr=  $(sshpass -p $pass ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=quiet sparrow@$ip -T df -h /eOffice/ | grep eOffice | awk -F' ' '{print $5}')
bip= $(sshpass -p $pass ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=quiet sparrow@$ip -T hostname -I | awk -F' ' '{print $2}')
echo -e "  \e[1;31m ------------------Server Configuration for $ip------------------   \e[0m  "
echo -e "  \e[1;32m Server IP             : $ip    \e[0m  "
echo -e "  \e[1;32m Hostname              : $host  \e[0m  "
echo -e "  \e[1;32m Redhat Version        : $rhel  \e[0m  "
echo -e "  \e[1;32m Total CPU Cores       : $cpu   \e[0m  "
echo -e "  \e[1;32m Total RAM             : $mem   \e[0m  "
echo -e "  \e[1;32m Total Space           : $ts    \e[0m  "
echo -e "  \e[1;32m Total Space Used      : $us    \e[0m  "
echo -e "  \e[1;32m Total Space Available : $da    \e[0m  "
echo -e "  \e[1;32m Total Used Pecentage  : $pr    \e[0m  "
echo -e "  \e[1;32m Backup IP             : $bip   \e[0m  "
done
