#!/bin/bash
pass="abc"
for i in $(seq 112 120);
do
ip=`echo "10.248.101.$i"`
_host=`sshpass -p $pass ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=quiet sparrow@$ip -T "hostname"`
echo -e "  \e[1;34m IP                  : $ip    \e[0m  "
echo -e "  \e[1;34m Hostname            : $_host \e[0m  "
a=`sshpass -p $pass ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=quiet sparrow@$ip -T "ls /eOffice/JApps/APPS/MIS/"`
if [ $? -eq 0 ]
then
_path=`sshpass -p $pass ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=quiet sparrow@$ip -T "cd /eOffice/JApps/APPS/MIS/ ; pwd"`
_war=`sshpass -p $pass ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=quiet sparrow@$ip -T "cd /eOffice/JApps/APPS/MIS/war-deploy/ ; ls | grep MIS | awk -F' ' '{print $1}'"`
sshpass -p $pass ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=quiet sparrow@$ip -T "/eOffice/JApps/Tomcat/MIS/bin/shutdown.sh ; sleep 30"
sshpass -p $pass ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=quiet sparrow@$ip -T "mv $_path/war-deploy/$_war  $_path/war-backup/$_war'_bak_21052017'"
sshpass -p $pass scp -r MIS sparrow@$ip:$_path/war-deploy/$_war
sshpass -p $pass ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=quiet sparrow@$ip -T "cp -r $_path/war-backup/$_war'_bak_28052017'/META-INF/context.xml $_path/war-deploy/$_war/META-INF/context.xml"
sshpass -p $pass ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=quiet sparrow@$ip -T "/eOffice/JApps/Tomcat/MIS/bin/startup.sh"
echo -e "  \e[1;34m WAR Deployed Successfully on $ip($_host) \e[0m  "
else 
echo "MIS doesn't exist in $_host $ip"
fi
done
