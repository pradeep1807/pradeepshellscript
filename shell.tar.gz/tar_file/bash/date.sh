#!/bin/bash
NOW=$(date +"%Y-%m-%d-%H%M")
echo $NOW
