#!/bin/bash
#echo "The variable name is $name"
name="pradeep"
echo "The variable name is $name"
work="Linux"
echo "Name of your dept. is $work"