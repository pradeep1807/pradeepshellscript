#!/bin/bash
echo "hello,What is your name?"
read name
echo "Good Morning $name"
echo "$name,What is your work?"
read  work
echo "You are $work, it's Great Work!"
#echo "$work"
sleep 1
echo "$name, what is date?"
echo "$name,date is today"
date +%F
echo "$name,what is time?"
sleep 2
echo "$name,current time is:-"
date +%T
sleep 2
echo "$name,What is current directory?"
echo "$name,your current directory is:-"
pwd
sleep 1
echo "$name,All the best!"