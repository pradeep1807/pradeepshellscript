#!/bin/bash
echo "Enter your group name"
read name
if [ "$name" == a ]
then
echo "You will give treat in Burger"
elif [ "$name" == b ]
then
echo "You will give treat in Beer"
elif [ "$name" == c ]
then
echo "You will give treat in Softdrink!"
else
echo "You type wrong group name!"
fi
