#!/bin/bash
Today=`date +%A`
echo "Today is $Today"
Date=`date +%F`
echo "Today is $Date"