#!/bin/bash
echo "What is your age"
read age
if [ $age -le 17 ]
then
echo "You are Child"
elif [ $age -ge 65 ]
then
echo "You are Old. God Bless You!"
elif [ $age -ge 18 ]
then
echo "You are Adult, Enjoy !"
fi