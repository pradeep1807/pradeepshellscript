#!/bin/bash
i=1
for day in [ "Mon", "Tue", "Wed" ]
do 
echo "Weekday $((i++)) : $day"
done
