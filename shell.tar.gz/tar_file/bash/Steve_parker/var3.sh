####positional parameters########
#!/bin/bash
echo "My name is `basename $0` - I was called as $0"
echo "My first parameters is: $1"
echo "My second parameters is: $2"
