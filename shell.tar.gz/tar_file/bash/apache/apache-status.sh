#!/bin/bash
systemctl status httpd
if [[ $? == 3 ]]; then
   echo "Httpd is down `date`" | mail pradeep.nicindia@gmail.com
   exit 1
fi
exit 0
