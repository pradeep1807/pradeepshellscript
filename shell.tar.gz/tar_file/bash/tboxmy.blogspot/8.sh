#!/bin/bash
#functions basics
#tutorials on function and local variables
NAME="Linux"
function display_name 
{
local NAME=`uname -a`
echo $NAME
}
function display_date 
{
local NAME=`date "+%D"`
echo $NAME
}
#function display_time
#{
#local NAME=`date "+%T"`
#echo $NAME
#}
echo $NAME
display_name
echo -n $NAME
display_date
#echo -n "$NAME"
#display_time
