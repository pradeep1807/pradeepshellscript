#!/bin/bash
#Example 2: Print variable from Linux Commands
s1=$(date +%Y%m%d)
echo $s1
