#!/bin/bash
#tutorials if/else
DIR="/var/log"
if [ -d $DIR ]then
echo "Directory $DIR exist"
else
echo "Directory $DIR does not exist"
fi
