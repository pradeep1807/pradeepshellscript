#!/bin/bash
#example 3: loop condition in brackets
#create the following loop_while3.sh and execute it.

while ((cow<=10)) ; do
       let cow++
       echo $cow
    if [ $cow -gt 10 ]; then
          let cow=0
    fi
done
