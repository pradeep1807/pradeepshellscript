#!/bin/bash
c=10
while [ $c -gt 0 ]; do
      echo Value of count is: $c
      let c=c-1
done
