#!/bin/bash
#Exmaple1: Print a text string
#Tutorials for variables
s="Hello World"
echo $s
