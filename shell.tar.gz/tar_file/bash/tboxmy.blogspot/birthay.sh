#!/bin/bash
echo "Enter the number of months eg. Jan 1,Feb 2...."
read n
if [ $n -eq 1 ]; then
echo -n "Name of candidate :-"
echo "Manoj"
fi
