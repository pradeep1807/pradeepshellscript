#!/bin/bash
#create the following script var_ifcondition1.sh and execute it.
#tutorials if/else
echo "[1]Disk usage,[2]Sockets in use, [9]Help.Choice:"
read CHOICE
if [ $CHOICE -eq 1 ]; then
    df
fi
if [ $CHOICE -eq 2 ]; then
    ss
fi
if [ $CHOICE -ge 3 ]; then
    echo "Type 1 or 2 and press enter"
fi
