#!/bin/bash
#The brace quotes {} are used to enclose a variable name.
#The back slash is used to display escape characters and otherwise non 
# printable characters.
#Tutorials on braces
#CITY=London
#COUNTRY=UK
echo "Enter the CITY name:-"
read CITY;
echo "Enter the COUNTRY name:-"
read COUNTRY;
echo "${CITY},${COUNTRY}"
echo "\"${CITY}\" is in ${COUNTRY}":

