#!/bin/bash
#Backup a folder
#Tutorials to backup HOME folder
if (backup -eq backup)
{
echo "It is already exist"
}
else
{
mkdir backup;
echo "directory is created";
}
cp -rfv /bash/tboxmy.blogspot/*.sh /bash/tboxmy.blogspot/backup/.
s1=$(date +%Y%m%d)
BACKUPFILE="$/bash/tboxmy.blogspot/backup$s1.tgz"
tar czf "$BACKUPFILE" $/bash/tboxmy.blogspot/tutorial
ls -l $BACKUPFILE
