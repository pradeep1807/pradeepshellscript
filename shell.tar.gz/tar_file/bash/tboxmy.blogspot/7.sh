#!/bin/bash
#Tutorials on back quotes
s1=`uname -a`
echo $s1
date "+T"
echo "Currently the linux have followinf socket connections"
#ss

