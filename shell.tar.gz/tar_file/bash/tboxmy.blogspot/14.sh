#!/bin/bash
#example 2: Read from a text file
#create the following script loop_while2.sh and execute it with a file input.
let count=0
while read LINE; do
      echo $LINE
      ((count++))
done
echo "Total lines: $count"
