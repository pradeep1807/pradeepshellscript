#!/bin/bash
echo "Hello,Good Morning!"
read $p
echo "What is your name?"
read $n
echo "What is your city name?"
read $c
