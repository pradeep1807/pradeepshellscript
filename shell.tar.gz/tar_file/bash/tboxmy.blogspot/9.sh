#!/bin/bash
#Arguments user input
#the commands read will prompt for the user to enter test and press Enter.
#Create following script var_user_input.sh and execute it.
#Tutorials on user input
echo "Enter a colour:"
read S1
echo "Enter a country name:"
read S2
echo "$S2 is feeling $S1"
