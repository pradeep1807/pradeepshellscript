#!/bin/bash
#tutorials if/else
S1=`date "+%a"`
echo "Guess a day between Mon and Sun:"
read g
if [ $g = $S1 ]; then
    echo "You read my mind"
else
    echo "Guess again"
fi
