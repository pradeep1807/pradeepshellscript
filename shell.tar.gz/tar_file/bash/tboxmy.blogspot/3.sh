#4. Builtin variables
#There are a number of environment variables and system variables that can be of use when doing scripting. These are also known as builtin variables. Useful commands to know are (printenv, env, set).
#
#Append to hello.sh with following;
#
#echo $HOME
#echo $BASH_VERSION
#Run hello.sh
#List of Builtin variables
#BASH_VERSION
#HOSTNAME
#CDPATH
#HISTFILE
#HISTSIZE
#HOME
#IFS
#LANG
#PATH
#PS1
#PS2
#TMOUT
#TERM
#SHELL
#DISPLAY
#EDITOR
#USER
#PWD
#.
#Environment variables are shaded and without shading are the system variables.
#
