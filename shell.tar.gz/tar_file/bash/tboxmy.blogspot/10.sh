#!/bin/bash
#Tutorilas if/else
echo "Name of Directory"
read DIR
if [ -d $DIR ]
then
    echo "Directory $DIR exist"
else
    echo "Directory $DIR does not exist"
fi
