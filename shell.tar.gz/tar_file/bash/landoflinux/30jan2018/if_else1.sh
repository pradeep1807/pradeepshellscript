#!/bin/bash
echo "Enter is your age:-"
read p
if [ $p -gt 70 ];then
 echo "You are too old"
elif [ $p -lt 20 ]
then 
echo "You are child "
else 
echo "You are young"
fi
