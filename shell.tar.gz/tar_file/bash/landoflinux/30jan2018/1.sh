#!/bin/bash
printf "\n Name of Script $0\n"
printf "\n Name of Arguments $#\n"
printf "Parameters Passed: $1 $2 $3 $4 $5 $6\n"
printf "\n Numeric variable with value greater than 9 ${nn}\n"

printf "\n All command Arguments-list of seperated items $@\n"
printf "\n All command arguments -A single item $*\n"
printf "\n All command arguments -A single item $$\n"
printf "\n All command arguments -A single item $?\n"
