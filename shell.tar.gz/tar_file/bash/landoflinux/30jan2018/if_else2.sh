#!/bin/bash
array1[0]=delhi
array1[1]=kolkata
array1[2]=
