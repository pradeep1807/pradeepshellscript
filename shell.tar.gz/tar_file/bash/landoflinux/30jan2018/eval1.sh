#!/bin/bash
printf "\nHello Pradeep your script name is $0\n"
printf "\nHello Pradeep your script name is $0\n"
