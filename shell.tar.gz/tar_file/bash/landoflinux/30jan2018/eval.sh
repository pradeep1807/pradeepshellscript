#!/bin/bash
printf "\nName of script $0\n"
var1="First"
var2=var1
echo '$'$var2
eval echo '$'$var2
