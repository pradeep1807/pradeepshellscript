#!/bin/bash
echo "What is you name"
read p
echo "$p, Hello Good morning"
echo "What is your working area?"
read work
echo "$work,it is good"
