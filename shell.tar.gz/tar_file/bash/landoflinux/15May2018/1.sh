#!/bin/bash
echo $0 ;   #heading 
echo $1 $2 $3 ;
echo $# ;
echo ${nn} ;  #numeric variables with values greater than 9
echo $@   # all 
