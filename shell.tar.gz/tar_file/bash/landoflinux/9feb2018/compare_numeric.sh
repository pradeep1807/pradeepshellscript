#!/bin/bash
echo "enter first number:-"
read x
echo "enter second number:-"
read y
printf "\nThe variable \$x has been assigned a value of $x \nThe variable \$y has been assigned a value of $y\n"
printf "\nTest x > y : x=$x y=$y\n"
if (( x > y )); then
    printf "x is greater than y\n"
else
    printf "x is less than y\n"
fi
