#!/bin/bash
echo "enter number which want you table"
read a
for i in { 1..10 }
do
echo "$a * $i = $(( $i * $a))"
done
