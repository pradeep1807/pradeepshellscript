#!/bin/bash
echo "Enter your age:-"
read p
if [ $p -lt 18 ] ; then
echo "you are able"
else
echo "you not able"
fi

