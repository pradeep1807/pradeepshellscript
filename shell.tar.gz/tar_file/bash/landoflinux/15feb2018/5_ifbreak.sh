#!/bin/bash
for ((i=1;i<=10;i++))
 do
   printf "\n i has a value of $i"
       if [ $i -eq 5 ]; then
          printf "\n Match made: Variable i has a value of 5\n"
          break
       fi
 done
