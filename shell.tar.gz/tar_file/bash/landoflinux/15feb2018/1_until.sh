#!/bin/bash
#
count = 1
until [ $count -gt 5 ]
do
   printf "Count has a value of $count\n"
((count++))
done
