#!/bin/bash
#
#for i in 1 2 3 4 5 6 7 8 9
for ((i=0;i<=10;i++))
do
printf "\n i has a value of $i"
   if [ $i -eq 5 ]; then
      printf "\n Match mode: variable i has a value of 5\n"
   break
fi
done
