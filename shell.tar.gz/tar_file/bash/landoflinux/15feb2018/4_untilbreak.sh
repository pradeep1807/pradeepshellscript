#!/bin/bash
c=1
until [ $c -eq 5 ]
do
printf "Count has a value of $c\n"
((c++))
if [ $c -eq 5 ]
  then
      printf "Count has a value of $count\n"
      printf "\nCount has reached 5, time for a break\n"
      break
fi
done
