#!/bin/bash
#c=1
#while [ $c -le 100000 ]
#do
#printf "hello $c\n"
#((c++))
#if [ $c -eq 10 ]
#then
#printf "count has a value of $c\n"
#printf "\ncount has reached 10,time for a break\n"
#break
#fi
#done
i=10
while [ $i -eq 10000 ]
do
echo "hello $i\n"
((i--))
break
done
