#!/bin/bash
string1=pradeep
string2=deep
if [ $string1 == $string2 ]; then
   echo "string1: $string1 is the same as string2: $string2"
else 
   echo "string1: $string1 is not same as string2: $string2"
fi
