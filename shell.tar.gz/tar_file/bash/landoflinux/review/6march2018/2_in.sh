#!/bin/bash
i=1
for day in Mon Tue Wed Thu Fri
