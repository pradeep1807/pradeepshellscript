#!/bin/bash
pwd=t
if [ -f /bash/landoflinux/review/27feb2018/test.txt ]; then
   echo "file found"
else
   echo "Sorry, file not found"
fi
