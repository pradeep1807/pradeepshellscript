#!/bin/bash
if [ -f /bash/landoflinux/review/27feb2018/pradeep.txt ]; then
  echo "file NoT found" 
