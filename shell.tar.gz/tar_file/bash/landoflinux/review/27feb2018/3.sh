#!/bin/bash
if [ -test obj ]; then
   echo "Test is True"
else
   echo "Test is False"
fi
