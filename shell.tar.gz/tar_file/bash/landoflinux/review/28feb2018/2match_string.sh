#!/bin/bash
echo "enter first string:-"
read first
echo "enter second string:-"
read second
if [ $first != $second ]; then
echo "first is not equal to second"
else 
echo "first is equal to second"
fi
