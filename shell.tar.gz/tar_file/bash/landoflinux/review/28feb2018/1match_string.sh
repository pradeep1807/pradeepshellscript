#!/bin/bash
echo "Enter the string one:-"
read one
echo "Enter the string two:-"
read two
#one=pradeep
#two=deep
if [ $one == $two ]; then
    echo "both are equal"
else
    echo "both are not equal"
fi
