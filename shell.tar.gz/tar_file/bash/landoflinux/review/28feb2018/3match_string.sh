#!/bin/bash
echo "enter first :-"
read f
echo "enter second:-"
read s
if [ $f \> $s ]; then
echo "first is lexically greater than second -b is greater than a"
