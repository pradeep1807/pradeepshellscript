#!/bin/bash
 
if [ $1 -gt 100 ]
then
 echo Hey that\'s a large number.
 pwd
fi

date
