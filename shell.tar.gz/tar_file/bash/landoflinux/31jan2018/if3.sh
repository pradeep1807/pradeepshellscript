#!/bin/bash
echo "Enter your age:-"
read a
if [ $a -lt 18 ]
then
echo "You are not able to go for party"
elif [ $a -gt 19 ]
then
echo "You are ready for party"
fi
