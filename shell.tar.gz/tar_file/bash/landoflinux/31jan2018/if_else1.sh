#!/bin/bash
echo "Enter number:-"
read p
if [ $p % 2 -eq 0 ]
 then
echo "number is even"
else
echo "number is odd"
fi
