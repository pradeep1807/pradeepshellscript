#!/bin/bash
#array=( india punjab haryana manipur maharastra )
echo -e "\nWhich state want you know capital \nindia\npunjab\nharyana\nmanipur\nmaharastra\n"
echo "Enter the city name:-"
read p
if [ $p == 'india' ]
 then
echo "capital of india is :- delhi"
elif [ $p == 'punjab' ]
then
echo "capital of punjab is :- chandigarh"
elif [ $p == 'haryana' ]
then
echo "capital of haryana is :- chandigarh"
elif [ $p == 'manipur' ]
then
echo "capital of manipur is :- dispur"
elif [ $p == 'maharastra' ]
then
echo "capital of maharastra is :- mumbai "
echo "do you want continue?"
read y
if [ $y == 'yes' ]
then
echo -e "\nWhich state want you know capital \nindia\npunjab\nharyana\nmanipur\nmaharastra\n"
elif [ $y == 'no' ]
then
exit
fi
fi
