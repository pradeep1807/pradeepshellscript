#!/bin/bash
echo "enter the number which number you want table"
read p
for i in ( i=1;i<=10;i++ )
do
echo "$p * $i = \n"
done
