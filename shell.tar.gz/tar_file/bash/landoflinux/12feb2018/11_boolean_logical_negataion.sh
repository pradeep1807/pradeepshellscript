#!/bin/bash
if [ -f /bash/landoflinux/12feb2018/pradeep.txt ]; then
echo "File find"
else
rm -rf /bash/landoflinux/12feb2018/pradeep.txt 
echo "File not find"
touch /bash/landoflinux/12feb2018/pradeep.txt
fi
