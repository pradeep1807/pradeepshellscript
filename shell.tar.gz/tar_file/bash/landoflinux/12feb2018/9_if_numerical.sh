#!/bin/bash
echo "Enter first number:-"
read a
echo "Enter second number:-"
read b
if ((a>b)) ; then
echo "a is greater than b\n"
else
 printf "a is less than b\n"
fi

