#!/bin/bash

#case statement
if [ -z $1 ]; then
    echo "You must specify a model name. e.g. Fiesta"
    exit
fi
#translate any uppercase characters into lowercase to simplify our test
newtest=$( echo "$1" | tr -s '[:upper:]' '[:lower:]' )
case $newtest in
fiesta)
  echo "You entered $1"
  echo "The model $1 is manufactured by Ford"
  ;;
mondeo)
  echo "You entered $1"
  echo "The model $1 is maufactured by Ford"
  ;;
*)
echo "Sorry, car $1 is not recognised"
esac
