#!/bin/bash
day=$1
if [ $day -lt 10 ]
then
echo "We are in the first part of the month"
elif [ $day -lt 20 ]
then
echo "We are in the middle of the month"
else
echo "We are in the last part of the month"
fi
