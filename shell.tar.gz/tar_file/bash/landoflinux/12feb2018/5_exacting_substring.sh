###exacting substring from a variable

#!/bin/bash
test="Welcome to the land of linux"
echo "Our variable test is ${#test} characters long"
test1=${test:0:7}
test2=${test:15:13}
echo $test1
echo $test2
