#/dev/null

#In the above example we are attempting to open the "/etc/shadow" file. 
#If we are successful then the echo statement "File opened successfully" 
#will be issued. If we were unable to open the file,
# then the echo statement "failed to open file" would be 
#displayed. (> /dev/null is used to throw away any output)

#!/bin/bash
su - root
sshpass=redhat!@#
cat /etc/shadow > /dev/null && echo "File opened successfully" || echo "File opened successfully"
