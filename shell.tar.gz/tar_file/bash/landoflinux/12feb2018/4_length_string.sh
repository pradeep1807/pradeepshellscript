#!/bin/bash
test="welcome to the land of linux"
#echo "Enter the string:-"
#read p
#p=$[#test]
echo "Our variable test is ${#test} characers long"
