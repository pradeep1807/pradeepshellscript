#!/bin/bash
file_list="/bash/landoflinux/12feb2018/pradeep.txt /bash/landoflinux/12feb2018/pradeep1.txt /bash/landoflinux/12feb2018/pradeep2.txt"
for files in $file_list
do 
[ -f $files ] && echo "file: $files exists" || echo "file: $files is missing"
done
