###command1 || command2
###command2 is only exected returns a non zero exit code.Simply this means run
###command1 successfully otherwise run commands2.

#!/bin/bash
grep "pradeep" /etc/passwd || echo "Failed"
#grep "pradeep1" /etc/passwd || echo "Failed"

