#!/bin/bash
for i in item1 item2 item3 item4 irem5
do
  echo $i
done
