#!/bin/bash
test="one.four.three"
echo "Before replacement: $test"
echo "After replacment:   ${test/fo*./two.}"
