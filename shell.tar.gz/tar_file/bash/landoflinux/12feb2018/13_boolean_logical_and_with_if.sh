### command1 && command2
### if "command1" successfully executes with an exit status of "0" True, then run 
### "command2". this functionality is very useful within scripts. 

#!/bin/bash

john=21
man=10
#echo "enter age of john"
#read $john
#echo "enter age of man"
#read $man
if [[ $john == "21" && $man == "9" ]]; then
   echo "John is $john and man is $man"
fi
if [[ $john == "21" && $man == "10" ]]; then
   echo "John is $john and man is $man"
fi
