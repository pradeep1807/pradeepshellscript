#!/bin/bash
echo "Enter first number:-"
read a
#echo "enter second number:-"
#read b
if [ $a -eq 20 ];
then
echo "it is equal to 20"
else
echo "is is not equal to 20"
fi
if [ $a -ge 20 ];
then
echo "it is greater than 20"
else
echo "it is not greater than 20"
fi

