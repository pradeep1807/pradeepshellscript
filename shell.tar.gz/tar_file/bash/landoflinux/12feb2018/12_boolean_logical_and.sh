#!/bin/bash
grep "pradeep" /etc/passwd && echo "pradeep found"
