#!/bin/bash
read -p "Please Enter some words followed by ENTER: " vara varb varc
echo "vara contains $vara"
echo "varb contains $varb"
echo "varc contains any remainig words $varc"

