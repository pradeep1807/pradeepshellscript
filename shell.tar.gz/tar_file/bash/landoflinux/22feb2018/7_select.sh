#!/bin/bash
clear
PS3="select month:-"
select month in January February March April
do
echo "you have chosen $month"
done
