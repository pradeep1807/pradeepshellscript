#!/bin/bash
echo "Please enter 3 words followed by ENTER:"
read first middle last
echo "Hello $first $middle $last"
