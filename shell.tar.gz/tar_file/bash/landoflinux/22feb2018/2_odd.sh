#!/bin/bash
read -p "Enter a number: " number
remainder=$(( $number % 2 ))
if [ $remainder -eq 0 ]; then
    echo "the number $number you entered is an even number"
else
    echo "The number you entered $number is an odd number"
fi
