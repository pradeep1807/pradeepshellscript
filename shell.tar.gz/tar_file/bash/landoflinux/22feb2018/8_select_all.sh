#!/bin/bash
clear
PS3="Select month a ENTER:-"
select month in Jan Feb March April Quit
do
case $month in
Jan)
   echo "Staring Month name is this"
;;
Feb)
   echo "It is second month of year"
;;
March)
   echo "Third month of year"
;;
April)
   echo "4th month of year" ;;
   Quit)
    echo "exiting menu"
    exit
   ;;
   *)
   echo "Please choose a valid entry (1-4)"
esac
done
