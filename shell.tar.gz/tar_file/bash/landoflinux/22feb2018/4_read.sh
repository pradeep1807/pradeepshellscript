#!/bin/bash
read -p "Please Enter 3 words followed by ENTER: " first middle last
echo "Hello $first $middle $last"
