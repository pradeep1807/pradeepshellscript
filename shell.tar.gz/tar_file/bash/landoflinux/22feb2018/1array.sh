#!/bin/bash
test=(one two three four five)
echo ${test[0]}
echo ${test[1]}
echo ${test[2]}
echo ${test[3]}
echo ${test[4]}
echo ${test[*]}
echo ${test[*]}
test[5]=six
echo ${test[*]}
