#!/bin/bash
read -p "Please Enter first word followed by ENTER: " first
read -p "Please Enter second word followed by ENTER: " second
read -p "Please Enter last word followed by ENTER: " last
echo "Hello $first $second $last"
