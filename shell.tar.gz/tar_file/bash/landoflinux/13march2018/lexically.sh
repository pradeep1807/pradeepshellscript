#!/bin/bash
string1=aa
string2=bb
if [ $string1\<$string2 ];then
   echo "string1 is lexically less than string2"
else
   echo "string1 is not lexically less than string2"
fi
