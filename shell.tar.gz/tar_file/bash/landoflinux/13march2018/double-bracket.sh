#!/bin/bash
name=testjohntext
if [[ "$name"==*john* ]]; then
    echo "The string \"john\" was found in the variable \$name"
fi
