#!/bin/bash
if id $1; then
      echo "Hello $1"
else
      echo "User not found"
fi
