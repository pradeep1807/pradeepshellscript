#!/bin/bash
for i in 1 2 3 4 5 6 7 8 9
do
   if [ $i -eq 5 ]; then
      printf "\n Skipping past 5, Continuing to next iteration\n"
      continue
   fi
  printf "\n Variable i has a value of $i\n"
done
