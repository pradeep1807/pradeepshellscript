#!/bin/bash
#for ((i=1;i<=4;i++))
#for i in 1 2 3

for ((j=32;j<=35;j++))
{
printf "\n\e[1;$jm Hello number is \n\e[0m"

}


