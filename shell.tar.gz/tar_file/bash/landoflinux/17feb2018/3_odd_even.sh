###### check odd and even ######

#!/bin/bash
printf "\e[1;34m\nEnter a number you want to check odd and even:-\n\e[0m"
read a
r=$(( a % 2 ))
if [ $r -eq 0 ]; then
printf "\e[1;30m\nNumber is even\n\e[0m"
else
printf "\e[1;34m\nNumber is odd\n\e[0m"
fi


