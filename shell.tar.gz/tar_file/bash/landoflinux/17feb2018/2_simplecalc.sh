#!/bin/bash
printf "\nEnter first number:-\n"
read a
printf "\nEnter second number:-\n"
read b
printf "\nEnter second number:-\n"
read z
c=$(( a + b + z ))
printf "\nTwo number addition is:-$c\n"

d=$(( a - b - z ))
printf "\nTwo number subtraction is:-$d\n"

e=$(( a / b / z ))
printf "\nTwo number division is:-$e\n"

f=$(( a * b * z ))
printf "\nTwo number multiplication is:-$f\n"

g=$(( a % b % z ))
printf "\nTwo number modulo is:-$g\n"

h=$(( a ** b ** z ))
printf "\nTwo number exponentiation is:-$h\n"
