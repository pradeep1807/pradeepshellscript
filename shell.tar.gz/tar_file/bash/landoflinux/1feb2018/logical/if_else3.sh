#!/bin/bash
read -p "Enter first number value:-" first
read -p "Enter second number value:-" second
if [ $first -le 10 -o $second -gt 20 ]
then
echo "OK"
else
echo "Not ok"
fi
