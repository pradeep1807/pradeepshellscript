#!/bin/bash
echo "Enter the number:-"
read p
if [ $p %2 -eq 0 ];
then
echo "it is even"
elif
then
echo "it is odd"
fi
