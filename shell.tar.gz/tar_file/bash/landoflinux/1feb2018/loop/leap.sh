#display and check leap year@@@

#!/bin/bash
echo "enter year value,which year value want you check:-"
read y
if [ $y % 4 -eq 0 ]
 then
echo "it is leap year"
else
echo "it is not leap year"
fi

