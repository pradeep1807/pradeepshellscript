#even and odd find##


#!/bin/bash
echo "Enter number:-"
read p
if [ `expr $p % 2` -eq 0 ]; then
echo "Even"
else
echo "Odd"
fi
