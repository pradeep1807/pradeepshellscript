#!/bin/bash
file_index="/bash/landoflinux/13feb2018/1.pdf /bash/landoflinux/13feb2018/2.pdf /bash/landoflinux/13feb2018/3.pdf"
for files in $file_index
do
[ -f $files ] && echo "file: $files exists" || echo "files is missing"
done

###
##[ -f files ] && echo "file: $"
