#!/bin/bash
 echo "Enter your password="
 read a
      if [ $a == redhat ]; then
 echo "Enter a number :-"
 read p
 for ((i=1;i<=10;i++))
 do
 pradeep="$p*$i"
 deep=$((p * i))
 echo $pradeep=$deep
 done
      else
      echo "You enter wrong password!"
      fi
 exit 0

