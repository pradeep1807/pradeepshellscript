#!/bin/bash
echo "Punch in time:-"
read i
echo "Punch out time:-"
read o
#p = `expr $o - $i`
p =$((o-i))
echo "your time is $p"

