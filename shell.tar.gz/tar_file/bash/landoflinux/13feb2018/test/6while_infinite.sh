#!/bin/bash
p=1
while :
do
echo "hello $p"
((p++))
done
