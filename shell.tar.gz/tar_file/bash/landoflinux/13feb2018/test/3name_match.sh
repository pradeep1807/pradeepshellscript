#!/bin/bash
echo "Enter your name:-"
read n
if [ $n == pradeep ]; then
echo "Enter your command:-"
read p
$t=/bin/bash
p=$t
elif [ $n == deep ]; then
echo "Enter your command:-"
read s
fi

