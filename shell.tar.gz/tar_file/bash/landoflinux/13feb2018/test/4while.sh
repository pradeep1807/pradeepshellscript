#!/bin/bash
i=1
while [ $i -le 5 ]
do
echo "it has a value of $i"
((i++))
done
