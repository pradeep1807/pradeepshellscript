#!/bin/bash
c=5
while [ $c -gt 0 ]
do
echo "this is $c"
((c--))
done
