#!/bin/bash
####path for file exists and non exists#####
file_list="/bash/landoflinux/13feb2018/pradeep1.txt /bash/landoflinux/13feb2018/pradeep2.txt /bash/landoflinux/13feb2018/pradeep3.txt"
###file checking via variable list####
for files in $file_list
do
[ -f $files ] && echo "file: $files exists" || echo "file: $files is missing"
done
