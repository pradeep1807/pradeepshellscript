#!/bin/bash
echo "Running Script as user $USER"
count=0
for i in $(cat ./userlist.txt)
do
echo "Adding user $i"
useradd -m -c "$i" $i
echo "Return code: $?"
((count++))
echo "Record processed are $count"
done
echo "Last lines form /etc/passwd follow"
tail -n $count /etc/passwd
