#!/bin/bash
#
HOST='ftp.myserver.net'
USER='userid'
PASSWD='password'
FILE='file.txt'

ftp -n $HOST <<MY_BLOCK
quote USER $USER
quote PASS $PASSWD
put $FILE
quit
MY_BLOCK
exit 0