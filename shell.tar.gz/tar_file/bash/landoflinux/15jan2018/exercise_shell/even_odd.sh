#!/bin/bash
echo "Enter number:" 
read n
if [ `expr $n % 2` = 0 ] then
echo "even number"
#else
#echo "Odd number"
fi