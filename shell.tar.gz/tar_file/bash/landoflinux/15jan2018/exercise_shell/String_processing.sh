#####Script1: String Processing################

#!/bin/bash
clear
echo "STRING MANIPULATION PROGRAM"
echo "1. COMPARE STRING"
echo "2. JOIN 2 STRING"
echo "3. LENGTH OF STRING"
echo "4. OCCOURANCE OF CHARACTER"
echo "5.OCCOURANCE OF WORD"
echo "6. REVERSE STRING"
echo "ENTER CHOICE:"
read ch
case $ch in
######compare sting
1)
echo "ENTER FIRST STRING:"
read str1
echo "ENTER SECOND STRING:"
read str2

len1=`echo $str1 | wc -c`
len2=`echo $str2 | wc -c`
if [ $len1 -gt $len2 ]; then
echo "BOTH STRINGS ARE OF SAME LENGTH"
elif [ $len1 -gt $len2 ]; then
echo "$str1 is greater than $str2"
else
echo "$str2 is greater than $str1"
fi
;;
#########joint two string
2)
echo "ENTER FIRST STRING:"
read str1
echo "ENTER SECOND STRING:"
read str2
str1="$str1+$str2"
echo "COMBINED STRING : $str1"
;;
#######length of string######
3)
echo "ENTER STRING:"
read str
len=`echo $str | wc -c`
echo "Length of string is $len"
;;
######occourance of character######
4)
echo "ENTER STRING:"
read str
echo "ENTER character of word to search:"
read search
len=`echo $str | wc -c`
i=1
while [ $i -lt $len ]
do
ch=`echo $str | cut -c $i`
echo $ch
i=`expr $i + 1`
done
;;

#####occourance of word############
5)
echo "NOT THERE:"
;;
#####reverse string###############
6)
echo "ENTER STRING:"
read str
echo "REVERSE STRING IS : "`echo $str | rev`
;;
*)
echo "ENTER PROPER CHOICE"
echo "NOT THERE"
;;
esac


