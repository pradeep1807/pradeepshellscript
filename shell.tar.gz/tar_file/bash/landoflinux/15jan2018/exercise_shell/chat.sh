#!/bin/bash
echo "Hello,What is your name!"
read name
echo "$name,Nice name"