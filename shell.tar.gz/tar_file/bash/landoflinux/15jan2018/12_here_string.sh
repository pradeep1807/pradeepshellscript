#!/bin/bash
myvar="one two three four five six seven"
tr a-z A-Z <<< $myvar
#my="0 1 2 3 4 5"
#tr 0-9 1.0 <<< $my
#hello