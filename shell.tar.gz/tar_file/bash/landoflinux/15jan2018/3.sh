#eval

#!/bin/bash

printf "\n Name of script $0 \n"
var1="First"
var2=var1
echo '$'var2
eval echo '$'$var2