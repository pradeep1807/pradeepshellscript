#!/bin/bash
#create function library
#Define Script Functions


lol_test() {
echo "Calling lol_test function"
ls -lF
}

echo_test() {
echo "Calling echo_test function"
ls -l | wc -l
}

my_test() {
echo "Calling my_test function"
ls | wc -w
}