#!/bin/bash
if [ -test object ]; then
echo "Test is True"
else
echo "Test is False"
fi