#!/bin/bash
function add()
{
sum=`expr $a + $b`
echo "add of two number: - $sum"
}
echo "Enter first number:-"
read a
echo "Enter Second number:-"
read b
add