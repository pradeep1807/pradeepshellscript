#shift command

#!/bin/bash
printf "\nName of script $0\n"
printf "Parameters Passed: $1 $2 $3 $4 $5 $6\n"
printf "number of arguments passed $#\n"
shift 1
printf "Parameters Passed: $1 $2 $3 $4 $5 $6\n"
shift 1
printf "Parameters Passed: $1 $2 $3 $4 $5 $6\n"
shift 2
printf "Parameters Passed: $1 $2 $3 $4 $5 $6\n"