#!/bin/bash
#
tr A-Z a-z << MY
one two three four five
one two three four five
aaa bbb ccc ddd eee fff
aaa bbb ccc ddd eee fff
FFF VISHAL HERO
MY