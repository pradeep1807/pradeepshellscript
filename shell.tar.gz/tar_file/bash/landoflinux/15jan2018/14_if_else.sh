#!/bin/bash
if [ -d /bash/landoflinux/pradeep ]; then
echo "Directory exist"
else
echo "Not found"
fi