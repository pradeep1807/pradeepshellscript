#!/bin/bash
#
#Path to our function library/bash/landoflinux/8.sh
. /bash/landoflinux/8.sh
echo "Lets call a function.."
lol_test
echo "And another one..."
echo_test
echo "And another function"
my_test