#variable

#!/bin/bash
printf "\nName of script $0\n"
printf "Parameters Passed: $1 $2 $3 $4 $5 $6\n"
printf " pwd $$"
printf "pradeep ${nn}"
printf "$*\n"
printf "PID - Process ID is $$\n"
printf "pwd - id is $?\n"