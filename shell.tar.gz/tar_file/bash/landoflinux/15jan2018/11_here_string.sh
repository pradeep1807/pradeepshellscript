#!/bin/bash
#
tr a-z A-Z <<< hello