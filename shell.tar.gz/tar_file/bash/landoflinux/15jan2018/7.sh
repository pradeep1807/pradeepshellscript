#script for used functions
#!/bin/bash
#
#define functions
lol_test() {
ls -lF
echo "Welcome to Linux"
}
echo "Now calling our test functions lol_test"
lol_test
echo "Calling our test functions again..."
lol_test
lol_test1(){
df -h
echo "Check disk free"
}
echo "Now calling for test1 functions lol_test1"
lol_test1
echo "Calling our test functions again..."
lol_test1