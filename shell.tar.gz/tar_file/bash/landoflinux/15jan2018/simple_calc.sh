#!/bin/bash
echo "Enter the first number:-"
read a
echo "Enter the second number:-"
read b
sum=`expr $a + $b`
sub=`expr $a - $b`
mul=`expr $a \* $b`
div=`expr $a / $b`
echo "Sum is:- $sum";
echo "sub is:- $sub";
echo "mul is: $mul";
echo "div is:- $div";