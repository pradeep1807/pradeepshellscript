#handling errors
#-a variable is an array
# -f use function names only
# -i variable is an integer
# -p used to display attributes of variable
# -r  read only - makes variables read-only
# -t gives variable the trace attributes
# -x makes each variable for export to subsequent commands via the environment

#!/bin/bash
#!/bin/bash
#
# Script Name: /bash/landoflinux/4.sh
#
# Author: John
# Date : 15.1.2018
#
# Description: The following script defines a variable called test that holds today's date.
#
# Run Information: This script is run manually.
#
# Standard Output: Any output is sent to a file called /bash/landoflinux/output.log
#
# Error Log: Any errors associated with this script are sent to a file called /home/john/scripts/errors.log
#

exec 1>>/bash/landoflinux/output.log
exec 2>>/bash/landoflinux/errors.log

test=$(date) 
echo "Today's date is $test"