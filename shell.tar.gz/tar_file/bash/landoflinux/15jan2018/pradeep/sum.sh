#!/bin/bash
#echo "Enter first number:-"
#read a
#echo "Enter Second number:-"
#read b
#sum = $(expr "$a" + "$b")
#echo "Sum is:= $sum "

##########

function add()
{
sum=`expr $a + $b`
echo "sum is: $sum";
}
function sub()
{
sub=`expr $a - $b`
echo "sub is: $sub";
}
function mul()
{
mul=`expr $a \* $b`
echo "mul is: $mul";
}

function div()
{
div=`expr $a / $b`
echo "div is: $div";
}

echo "Enter the vaule of a";
read a
echo "Enter the vaule of b";
read b
add
sub
mul
div