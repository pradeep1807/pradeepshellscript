#!/bin/bash
#shell script to given numbers sum all digit
#eg 343=3+4+3=10
#algorithm
#1) input number n
#2) set sum=0,sd=0
#3)find single digit in sd as n % 10 it will give (left most digit)
#4)construct sum no as sum=sum+sd
#5)decrement n by 1
#6)is n is greater than zero,if yes goto step 3,otherwise next step
#7)Print sum
#
if [ $# -ne 1 ]
then 
echo "Usage $0 number"
echo "I will find sum of all digit for given nuumber"
echo "For eg. $0 123,I will print 6 as sum of all digit(1+2+3)"
exit 1
fi
n=$1
sum=0
sd=0
while [ $n -gt 0 ]
do
sd=`expr $n % 10`
sd=`expr $sum + $sd`
n=`expr $n/10`
done
echo "Sum of digit for number is $sum"
