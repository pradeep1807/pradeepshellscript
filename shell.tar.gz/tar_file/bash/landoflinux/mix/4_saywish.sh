#!/bin/bash
#3. shell script to say Good morning/Afternoon/Evening as you log in
temph=`date | cut -c12-13`
dat=`date +"%A%d in %B of %Y (%r)"`
if [ $temph -lt 12 ]
then
mess="Good Morning $LOGNAME, Have nice day!"
fi
if [ $temph -gt 12 -a $temph -le 16 ]
then
mess="Good Afternoon $LOGNAME"
if [ $temph -gt 16 -a $temph -le 18 ]
then
mess="Good Evening $LOGNAME"
fi

if which dialog > /dev/null
then
dialog -backtitle "Linux Shell Script"\
-title "(-: Welcome to linux:-)"\
-infobox "\n$mess\nThis is $dat" 6 60
echo -n "Press a key to continue..."
read
clear
else
echo -e "$mess\nThis is $dat"
fi
