#!/bin/bash
#sort the given five number in ascending order
declare nos[5]=(4-1 2 66 10)
#
#Prints the number before sorting
echo "Orginal Number in array:"
for ((i=0;i<=4;i++))
do
echo ${nos[$i]}
done
#
#Now do the sorting of numbers
#
for ((i=0;i<=4;i++))
do
for ((j=$i;j<=4;j++))
do
if [ ${nos[$i]} -gt ${nos[$j]} ]; then
t=${nos[$i]}
nos[$i]=${nos[$j]}
nos[$j]=$t
fi
done
done
#
#print the sorted number
#
echo -e "\n Sorted Numbers in Ascending Order:"
for ((i=0;i<=4;i++))
do
echo ${nos[$i]}
done
#
#

