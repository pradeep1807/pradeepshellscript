#!/bin/bash
echo "Enter your name?"
read name
echo "$name,Good day"
echo "what are you doing?"
read work
echo "your $work, Good"
