#!/bin/bash
test=(even odd) # test[0]='even' test[1]='odd'
read -p "Enter a number: " number
echo "the number entered is ${test[$((number%2))]}"
