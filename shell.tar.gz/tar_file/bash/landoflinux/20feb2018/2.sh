zenity –entry –title=”Favorite Website” –text=”What is your favorite website?”
