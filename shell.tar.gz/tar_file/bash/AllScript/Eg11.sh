#Example 11 Simple if/else decision
#the if/else command is space sensitive.It starts with "if" and ends with "fi".The conditions is within a square bracket[] and can be in any one of these test
#1 numerical comparision (-lt,-gt,-le,-ge,-eq,-ne)
#2 string comparision (=,!=,<,>,-n S1,-z S1)
#3 file test
#-b filename file is a block special file
#-c filename file is a special character file
#-d directoryname directory exist
# -e filename file exist
#-f filename regular file exist and not a directory
#-G filename file exists and is set-group-id 
