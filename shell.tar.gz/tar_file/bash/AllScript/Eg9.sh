#Example 9 Script arguments
#!/bin/bash
echo "Arguments are"
echo $1
echo $2
echo $3
echo "All are stored as $@"
echo "Total number of arguments are $#"
