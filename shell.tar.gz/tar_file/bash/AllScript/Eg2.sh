#Example 2 : Print variable from linux commands
#!/bin/bash
NAME="Hello World"
S1=$(date +%Y%m%d)
echo $S1
