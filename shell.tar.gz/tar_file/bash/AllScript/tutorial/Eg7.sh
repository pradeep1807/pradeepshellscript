#Example 7 Linux command in scripts
#!/bin/bash
#Tutorials on back quotes
S1=`uname -a`
echo $S1
date "+T"
echo "Currently the linux have following socket connections"
ss
