#Example6 Seperate Variables names and black slash
#!/bin/bash
#tutorials on braces
CITY=London
COUNTRY=UK
echo "${CITY},${COUNTRY}"
echo "\"${CITY}\" is in ${COUNTRY}"
