#Backup a Folder
#!/bin/bash
#tutorials to backup Home Folder
S1=$(date +%Y%m%d)
BACKUPFILE="$HOME/AllScript/tutorial-$S1.tgz"
tar czf "$BACKUPFILE" $HOME/AllScript/tutorial
ls -l $BACKUPFILE
######################################

