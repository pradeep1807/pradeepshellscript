#Example 10 Accepting user input
#!/bin/bash
#tutorials on user input
echo "Enter a colour:"
read S1
echo "Enter a country name:"
read S2
echo "$S2 is feeling $S1"
