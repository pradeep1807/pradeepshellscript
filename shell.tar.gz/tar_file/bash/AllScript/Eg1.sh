#Example 1 Print a text String
#!/bin/bash
#tutorials for variables
NAME="Hello World"
echo $NAME
