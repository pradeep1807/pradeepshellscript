#!/bin/bash
export LC_ALL=C  #make output in English eg for later use with "du | grep"

TMP_PATH=/tmp/speedtest_data/
TEST_TIME=5

rm -rf $TMP_PATH && mkdir $TMP_PATH

links=("http://client.cdn.gamigo.com/bp/eu/com/110a/BPClientSetup-2b.bin" "http://client.cdn.gamigo.com/bp/eu/com/110a/BPClientSetup-1b.bin" "http://client.cdn.gamigo.com/bp/eu/com/110a/BPClientSetup-1c.bin" "http://ftp.ntua.gr/pub/linux/ubuntu-releases-dvd/quantal/release/ubuntu-12.10-server-armhf+omap.img" "http://ftp.funet.fi/pub/Linux/INSTALL/Ubuntu/dvd-releases/releases/12.10/release/ubuntu-12.10-server-armhf+omap.img" "http://ftp.icm.edu.pl/pub/Linux/opensuse/distribution/13.2/iso/openSUSE-13.2-DVD-x86_64.iso")

echo "Testing download"

for link in ${links[*]}
do
    timeout $TEST_TIME wget -q -P $TMP_PATH $link &
done

wait

total_bytes=$(du -c $TMP_PATH | grep total | awk '{print $1}')

echo "Cleaning up"
rm -rf $TMP_PATH

speed=$(expr $total_bytes / $TEST_TIME)

echo "Speed is $speed Kb/s"

exit 0
