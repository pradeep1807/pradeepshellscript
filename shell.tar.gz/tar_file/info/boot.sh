#!/bin/bash
DATE=$(date +'%F %H:%M:%S')
DIR=/info
echo "last Boot date and time: $DATE" >> $DIR/file1.txt

