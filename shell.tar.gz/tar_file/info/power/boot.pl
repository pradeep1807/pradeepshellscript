#! /usr/bin/perl

use strict;
use warnings;
use POSIX qw{ strftime };

undef $/;

$\ = "\n";
$, = '';
my $reclen   = 384; # sizeof (struct utmp)
my $linesize =  32; # value of UT_LINESIZE in /usr/include/bits/utmp.h
my $namesize =  32; # value of UT_NAMESIZE in /usr/include/bits/utmp.h
my $hostsize = 256; # value of UT_HOSTSIZE in /usr/include/bits/utmp.h
my $wtmpfile = '/var/log/wtmp';
my $entry_template = "(a$reclen)*";
my $utmp_template  = "I x4 x$linesize x4 x$namesize x$hostsize x4 x4 I";
my @UT_TYPE  = qw{ Empty RunLvl Boot NewTime OldTime Init Login Normal Term Account };
open FH, '<', $wtmpfile or die $wtmpfile;
my $boot = undef;
foreach my $entry (unpack $entry_template, <FH>) {
    my ($type, $when) = unpack $utmp_template, $entry;
        $boot = $when if $UT_TYPE[$type] eq 'Boot';
        }

        close FH;
        print strftime '%Y-%m-%d %H:%M:%S %Z', localtime $boot if defined $boot;
