#!/bin/bash
DATE=$(date +'%F %H:%M:%S')
DIR=/info/power
last -x | grep shutdown | head -1 | awk -F' ' '{print $5" "$6" "$7" "$8}' >> $DIR/shutdown.txt
#echo "last Shutdown date and time: $DATE" >> $DIR/shutdown.txt

